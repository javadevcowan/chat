# Kotlin, SpringBoot and WebSockets

This repository was created to host the source code for the Medium blog post "Kotlin, SpringBoot and WebSockets". 

https://medium.com/@codemwnci/kotlin-springboot-and-websockets-276029b22482

This simple application contains the files necessary for a simple javascript Chat application that communicates with a Kotlin serverside. The serverside uses SpringBoot to enable WebSocket connectivity to broadcast chat messages to everyone in the chat room. 
